# Nectarine Platform — Build Step 1

The pricing engine + admin console, running on a real database (Supabase).
This is the foundation every later module builds on: storefront, Zinc
ordering, payments, and the ops pipeline all read the configuration you
manage here.

## What you need before starting

1. **Node.js** — the engine that runs the app on your computer.
   Download the LTS version from https://nodejs.org and install it with
   all default options. To confirm it worked, open a terminal
   (Windows: search "PowerShell" · Mac: search "Terminal") and type:
   ```
   node -v
   ```
   You should see a version number like `v22.x.x`.

2. **A Supabase account** — this is your database, free to start.
   Go to https://supabase.com → Start your project → sign up.
   Create a **New project**: name it `nectarine`, set a strong database
   password (save it somewhere safe), choose the region closest to your
   customers' traffic (Europe/Frankfurt is a good pick from Tanzania),
   and click Create. Wait ~2 minutes while it provisions.

## Setting up (one time, ~10 minutes)

**Step 1 — Create the database tables.**
In your Supabase dashboard, click **SQL Editor** in the left sidebar →
**New query**. Open the file `supabase/migrations/001_init.sql` from this
project in any text editor, copy ALL of it, paste it into the SQL editor,
and click **Run**. You should see "Success. No rows returned."

**Step 2 — Get your keys.**
In Supabase: **Project Settings** (gear icon) → **API**. You need two things:
- **Project URL** (looks like `https://abcdefgh.supabase.co`)
- **service_role** key (under "Project API keys" — click Reveal)

**Step 3 — Give the keys to the app.**
In this project folder, find `.env.example`. Make a copy of it and rename
the copy to exactly `.env.local`. Open it in a text editor and replace the
placeholder values with your real URL and key. Save.

> The service_role key is powerful — it bypasses all database security.
> Never share it, never put it in WhatsApp/email, never publish this
> folder online with the key inside. We add proper login before anything
> goes on the public internet.

**Step 4 — Install and run.**
In the terminal, navigate into this folder and run:
```
cd path/to/nectarine-platform
npm install
npm run dev
```
The first command downloads the app's building blocks (1–3 minutes).
When you see `Ready`, open your browser at **http://localhost:3000**

You should see the Nectarine pricing console. Change a rate, click
**Save changes**, refresh the page — your change is still there. It now
lives in your database, not the browser.

## If something goes wrong

- **"Almost there — connect your database"** → your `.env.local` is
  missing or still has placeholder values. Redo Step 3, then stop the
  app (Ctrl+C) and run `npm run dev` again.
- **"Database connected, but something is off"** → the migration didn't
  run. Redo Step 1.
- **`npm` is not recognized** → Node.js isn't installed or the terminal
  was open during install. Close the terminal, open a new one, retry.

## What's in this project

```
supabase/migrations/001_init.sql   All database tables + starting data
src/lib/engine.js                  The pricing engine (pure logic)
src/lib/db.js                      Database connection + config loader
src/app/actions.js                 Save operations (server side)
src/app/page.jsx                   Entry page (loads config from DB)
src/components/AdminConsole.jsx    The admin console UI
src/app/globals.css                Styling
```

## What comes next (build plan)

- Step 2: Zinc adapter + paste-a-link quote flow
- Step 3: Staff login + database security rules
- Step 4: Storefront (US region) + catalog
- Step 5: Mobile money checkout
- Step 6: Order pipeline + warehouse intake
