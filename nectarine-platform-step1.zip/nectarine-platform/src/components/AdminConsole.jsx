"use client";

import { useMemo, useState } from "react";
import { computeQuote, fmtTZS, fmt2 } from "../lib/engine";
import { saveRegions, saveFx, saveCategories, saveSettings } from "../app/actions";

const SYMBOLS = { USD: "$", GBP: "£" };

function Field({ label, children, hint }) {
  return (
    <label className="fld">
      <span className="fld-l">{label}</span>
      {children}
      {hint ? <span className="fld-h">{hint}</span> : null}
    </label>
  );
}

function NumIn({ value, onChange, step = "any", suffix }) {
  return (
    <span className="numwrap">
      <input type="number" step={step} value={value} onChange={(e) => onChange(e.target.value)} />
      {suffix ? <em>{suffix}</em> : null}
    </span>
  );
}

function SaveBar({ onSave }) {
  const [state, setState] = useState({ busy: false, msg: "", err: false });
  return (
    <div className="savebar">
      <button
        className="savebtn"
        disabled={state.busy}
        onClick={async () => {
          setState({ busy: true, msg: "", err: false });
          const res = await onSave();
          setState({
            busy: false,
            msg: res.ok ? "Saved" : res.error || "Save failed",
            err: !res.ok,
          });
        }}
      >
        {state.busy ? "Saving…" : "Save changes"}
      </button>
      {state.msg ? <span className={"savemsg" + (state.err ? " err" : "")}>{state.msg}</span> : null}
    </div>
  );
}

export default function AdminConsole({ initial }) {
  const [tab, setTab] = useState("quote");
  const [regions, setRegions] = useState(initial.regions);
  const [fxRates, setFxRates] = useState(initial.fxRates);
  const [cats, setCats] = useState(initial.categories);
  const [settings, setSettings] = useState(initial.settings);
  const [input, setInput] = useState({
    regionCode: initial.regions[0]?.code || "USA",
    price: 89, qty: 1, weightKg: 1.2,
    dimsKnown: false, lenCm: 30, widCm: 22, htCm: 12,
    catId: initial.categories[0]?.id || 1,
    itemName: "Denim jacket",
  });

  const region = regions.find((r) => r.code === input.regionCode) || regions[0];
  const fxRow = fxRates.find((f) => f.currency === region.currency);
  const category = cats.find((c) => c.id === Number(input.catId)) || cats[0];
  const sym = SYMBOLS[region.currency] || "";

  const q = useMemo(
    () =>
      computeQuote({
        region,
        fxRate: Number(fxRow?.mid_rate) || 0,
        bufferPct: settings.fx_buffer_pct,
        category,
        settings,
        input,
      }),
    [region, fxRow, category, settings, input]
  );

  const setIn = (k, v) => setInput((p) => ({ ...p, [k]: v }));
  const setReg = (code, k, v) =>
    setRegions((p) => p.map((r) => (r.code === code ? { ...r, [k]: v } : r)));
  const setCat = (id, k, v) =>
    setCats((p) => p.map((c) => (c.id === id ? { ...c, [k]: v } : c)));
  const setSet = (k, v) => setSettings((p) => ({ ...p, [k]: v }));

  const tabs = [
    ["quote", "Quote engine"],
    ["rates", "Rate cards"],
    ["cats", "Categories & packaging"],
    ["fx", "FX & currency"],
    ["settings", "Settings"],
  ];

  return (
    <div className="shell">
      <header className="top">
        <h1><b>Nectarine</b> pricing console</h1>
        <span>Connected to your database — changes here price the storefront</span>
      </header>

      <nav className="nav">
        {tabs.map(([k, l]) => (
          <button key={k} className={tab === k ? "on" : ""} onClick={() => setTab(k)}>{l}</button>
        ))}
      </nav>

      <main className="main">
        {tab === "quote" && (
          <>
            <h2>Quote engine</h2>
            <p className="sub">
              Live simulator using the saved configuration. Edits in other tabs preview
              here immediately; they apply to real quotes once saved.
            </p>
            <div className="grid2">
              <div className="panel">
                <div className="fields" style={{ marginBottom: 15 }}>
                  <Field label="Shopping region">
                    <select value={input.regionCode} onChange={(e) => setIn("regionCode", e.target.value)}>
                      {regions.map((r) => (
                        <option key={r.code} value={r.code}>{r.label}</option>
                      ))}
                    </select>
                  </Field>
                  <Field label="Item">
                    <input value={input.itemName} onChange={(e) => setIn("itemName", e.target.value)} />
                  </Field>
                  <Field
                    label={`Store price (${region.currency})`}
                    hint={Number(input.price) >= settings.high_value_threshold
                      ? `High value — ${settings.high_value_pct}% handling applies`
                      : undefined}
                  >
                    <NumIn value={input.price} onChange={(v) => setIn("price", v)} suffix={sym} />
                  </Field>
                  <Field label="Quantity">
                    <NumIn value={input.qty} onChange={(v) => setIn("qty", v)} step="1" />
                  </Field>
                  <Field label="Category">
                    <select value={input.catId} onChange={(e) => setIn("catId", e.target.value)}>
                      {cats.map((c) => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  </Field>
                  <Field label="Deadweight per unit">
                    <NumIn value={input.weightKg} onChange={(v) => setIn("weightKg", v)} suffix="kg" />
                  </Field>
                </div>
                <Field label="Package dimensions">
                  <div className="modes">
                    <button className={!input.dimsKnown ? "on" : ""} onClick={() => setIn("dimsKnown", false)}>
                      Unknown — estimate
                    </button>
                    <button className={input.dimsKnown ? "on" : ""} onClick={() => setIn("dimsKnown", true)}>
                      Known — enter box size
                    </button>
                  </div>
                </Field>
                {input.dimsKnown && (
                  <div className="fields" style={{ marginTop: 13, maxWidth: 420 }}>
                    <Field label="Length"><NumIn value={input.lenCm} onChange={(v) => setIn("lenCm", v)} suffix="cm" /></Field>
                    <Field label="Width"><NumIn value={input.widCm} onChange={(v) => setIn("widCm", v)} suffix="cm" /></Field>
                    <Field label="Height"><NumIn value={input.htCm} onChange={(v) => setIn("htCm", v)} suffix="cm" /></Field>
                  </div>
                )}
                <p className="note">
                  Basis: {q.basis}. Chargeable {fmt2(q.totalKg)} kg total.
                  {q.estimated
                    ? ` Final weight is confirmed at the ${region.label} warehouse; the price only changes if it moves more than ${settings.variance_pct}%.`
                    : ""}
                </p>
              </div>

              <aside className="slip" aria-label="Quotation">
                <div className="slip-h">
                  <div className="no">Quotation — {input.itemName || "Item"}</div>
                  <div className="meta">
                    {region.label} → Dar es Salaam · Air freight, all-inclusive ·
                    {" "}valid {settings.quote_validity_hrs} hrs
                  </div>
                </div>
                <table>
                  <tbody>
                    <tr>
                      <td>Product
                        <span className="cap">{q.qty} × {sym}{fmt2(input.price)} @ {fmt2(q.fxEff)}</span>
                      </td>
                      <td>{fmtTZS(q.productTZS)}</td>
                    </tr>
                    <tr>
                      <td>Shipping &amp; clearance
                        <span className="cap">{fmt2(q.totalKg)} kg × {sym}{fmt2(region.rate_per_kg)}/kg — all-inclusive</span>
                      </td>
                      <td>{fmtTZS(q.shippingTZS)}</td>
                    </tr>
                    {q.isHighValue && (
                      <tr>
                        <td>High-value handling
                          <span className="cap">{settings.high_value_pct}% of item value ({"≥"} {sym}{settings.high_value_threshold})</span>
                        </td>
                        <td>{fmtTZS(q.hvTZS)}</td>
                      </tr>
                    )}
                    {settings.service_fee_pct > 0 && (
                      <tr>
                        <td>Service fee <span className="cap">{settings.service_fee_pct}%</span></td>
                        <td>{fmtTZS(q.serviceTZS)}</td>
                      </tr>
                    )}
                    {settings.payment_fee_pct > 0 && (
                      <tr>
                        <td>Payment processing <span className="cap">{settings.payment_fee_pct}%</span></td>
                        <td>{fmtTZS(q.feeTZS)}</td>
                      </tr>
                    )}
                    <tr className="tot">
                      <td>Customer pays</td>
                      <td>{fmtTZS(q.total)}</td>
                    </tr>
                  </tbody>
                </table>
                <div className="foot">
                  <span>{q.qty > 1 ? `${fmtTZS(q.perUnit)} per unit · ` : ""}Delivery {region.eta}</span>
                  {q.estimated
                    ? <span className="chip est">Estimated — confirmed at warehouse</span>
                    : <span className="chip">Final — measured dimensions</span>}
                </div>
              </aside>
            </div>
          </>
        )}

        {tab === "rates" && (
          <>
            <h2>Rate cards</h2>
            <p className="sub">
              One flat all-inclusive rate per corridor, in origin currency, applied to
              chargeable weight. Save to apply to all new quotes.
            </p>
            <div className="cardrow">
              {regions.map((r) => (
                <div className="panel" key={r.code}>
                  <div className="rc-h">
                    <h3>{r.label}</h3>
                    <span>{r.currency} corridor</span>
                  </div>
                  <table className="tbl">
                    <tbody>
                      <tr>
                        <td>All-inclusive rate per kg</td>
                        <td>
                          <input type="number" step="0.5" value={r.rate_per_kg}
                            onChange={(e) => setReg(r.code, "rate_per_kg", e.target.value)} />
                        </td>
                      </tr>
                      <tr>
                        <td>Minimum chargeable weight</td>
                        <td>
                          <input type="number" step="0.5" value={r.min_kg}
                            onChange={(e) => setReg(r.code, "min_kg", e.target.value)} />
                        </td>
                      </tr>
                      <tr>
                        <td>Delivery window</td>
                        <td>
                          <input className="wide" value={r.eta}
                            onChange={(e) => setReg(r.code, "eta", e.target.value)} />
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              ))}
            </div>
            <SaveBar onSave={() => saveRegions(regions)} />
          </>
        )}

        {tab === "cats" && (
          <>
            <h2>Categories &amp; packaging</h2>
            <p className="sub">
              Parcel-bag categories are charged on deadweight; boxed categories get an
              estimated uplift (deadweight × factor) when the box size is unknown.
              Tune factors as warehouse measurements come in.
            </p>
            <div className="panel" style={{ maxWidth: 700 }}>
              <table className="tbl">
                <thead>
                  <tr><th>Category</th><th>Usually ships as</th><th>Box factor</th><th></th></tr>
                </thead>
                <tbody>
                  {cats.map((c) => (
                    <tr key={c.id}>
                      <td style={{ width: "45%" }}>
                        <input className="wide" value={c.name}
                          onChange={(e) => setCat(c.id, "name", e.target.value)} />
                      </td>
                      <td>
                        <select value={c.pack_type}
                          onChange={(e) => setCat(c.id, "pack_type", e.target.value)}>
                          <option value="bag">Parcel bag</option>
                          <option value="box">Box</option>
                        </select>
                      </td>
                      <td>
                        {c.pack_type === "box" ? (
                          <input type="number" step="0.1" value={c.box_factor}
                            onChange={(e) => setCat(c.id, "box_factor", e.target.value)} />
                        ) : (
                          <span style={{ color: "var(--mut)" }}>deadweight</span>
                        )}
                      </td>
                      <td>
                        <button className="rowbtn" onClick={() => setCats((p) => p.filter((x) => x.id !== c.id))}>
                          Remove
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <button className="addbtn"
                onClick={() => setCats((p) => [...p, { id: "new-" + Date.now(), name: "New category", pack_type: "box", box_factor: 1.4 }])}>
                Add category
              </button>
              <SaveBar onSave={() => saveCategories(cats)} />
            </div>
          </>
        )}

        {tab === "fx" && (
          <>
            <h2>FX &amp; currency</h2>
            <p className="sub">
              Exchange rates convert origin-currency costs into TZS. The buffer (in Settings)
              protects your margin against movement between quote and settlement.
            </p>
            <div className="panel" style={{ maxWidth: 560 }}>
              <div className="kpis">
                {fxRates.map((f) => (
                  <div className="kpi" key={f.currency}>
                    <b>{fmt2(Number(f.mid_rate) * (1 + settings.fx_buffer_pct / 100))}</b>
                    <span>Effective {f.currency} → TZS</span>
                  </div>
                ))}
              </div>
              <div className="fields">
                {fxRates.map((f) => (
                  <Field key={f.currency} label={`${f.currency} → TZS mid rate`}>
                    <NumIn value={f.mid_rate}
                      onChange={(v) => setFxRates((p) => p.map((x) => x.currency === f.currency ? { ...x, mid_rate: v } : x))} />
                  </Field>
                ))}
                <Field label="FX buffer" hint="Added on top of the mid rate">
                  <NumIn value={settings.fx_buffer_pct} onChange={(v) => setSet("fx_buffer_pct", v)} suffix="%" />
                </Field>
              </div>
              <SaveBar onSave={async () => {
                const a = await saveFx(fxRates);
                if (!a.ok) return a;
                return saveSettings({ fx_buffer_pct: settings.fx_buffer_pct });
              }} />
            </div>
          </>
        )}

        {tab === "settings" && (
          <>
            <h2>Settings</h2>
            <p className="sub">Global levers applied to every quote across both corridors.</p>
            <div className="panel" style={{ maxWidth: 680 }}>
              <div className="fields">
                <Field label="Volumetric divisor" hint="L×W×H ÷ this = kg">
                  <NumIn value={settings.volumetric_divisor} onChange={(v) => setSet("volumetric_divisor", v)} />
                </Field>
                <Field label="High-value threshold" hint="Per unit, origin currency">
                  <NumIn value={settings.high_value_threshold} onChange={(v) => setSet("high_value_threshold", v)} />
                </Field>
                <Field label="High-value handling" hint="% of item value">
                  <NumIn value={settings.high_value_pct} onChange={(v) => setSet("high_value_pct", v)} suffix="%" />
                </Field>
                <Field label="Service fee" hint="Optional, % of product value">
                  <NumIn value={settings.service_fee_pct} onChange={(v) => setSet("service_fee_pct", v)} suffix="%" />
                </Field>
                <Field label="Payment fee" hint="Optional gateway pass-through">
                  <NumIn value={settings.payment_fee_pct} onChange={(v) => setSet("payment_fee_pct", v)} suffix="%" />
                </Field>
                <Field label="Round total up to" hint="Clean customer prices">
                  <NumIn value={settings.round_to_tzs} onChange={(v) => setSet("round_to_tzs", v)} suffix="TZS" />
                </Field>
                <Field label="Quote validity" hint="Price lock at checkout">
                  <NumIn value={settings.quote_validity_hrs} onChange={(v) => setSet("quote_validity_hrs", v)} suffix="hrs" />
                </Field>
                <Field label="Adjustment threshold" hint="Re-bill or refund only beyond this variance">
                  <NumIn value={settings.variance_pct} onChange={(v) => setSet("variance_pct", v)} suffix="%" />
                </Field>
              </div>
              <SaveBar onSave={() => saveSettings(settings)} />
            </div>
          </>
        )}
      </main>
    </div>
  );
}
