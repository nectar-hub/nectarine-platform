"use server";

import { revalidatePath } from "next/cache";
import { db } from "../lib/db";

// Each action saves one section of the admin console.
// Returns { ok: true } or { ok: false, error } so the UI can show feedback.

export async function saveRegions(regions) {
  const client = db();
  if (!client) return { ok: false, error: "Database not configured" };
  const rows = regions.map((r) => ({
    code: r.code,
    label: r.label,
    currency: r.currency,
    rate_per_kg: Number(r.rate_per_kg) || 0,
    min_kg: Number(r.min_kg) || 0,
    eta: r.eta || "",
    active: r.active !== false,
  }));
  const { error } = await client.from("regions").upsert(rows);
  if (error) return { ok: false, error: error.message };
  revalidatePath("/");
  return { ok: true };
}

export async function saveFx(fxRates) {
  const client = db();
  if (!client) return { ok: false, error: "Database not configured" };
  const rows = fxRates.map((f) => ({
    currency: f.currency,
    mid_rate: Number(f.mid_rate) || 0,
    updated_at: new Date().toISOString(),
  }));
  const { error } = await client.from("fx_rates").upsert(rows);
  if (error) return { ok: false, error: error.message };
  revalidatePath("/");
  return { ok: true };
}

export async function saveCategories(categories) {
  const client = db();
  if (!client) return { ok: false, error: "Database not configured" };

  const rows = categories.map((c, i) => {
    const row = {
      name: c.name,
      pack_type: c.pack_type,
      box_factor: Number(c.box_factor) || 1,
      sort: i + 1,
    };
    if (c.id != null && !String(c.id).startsWith("new-")) row.id = c.id;
    return row;
  });

  const { data: upserted, error } = await client
    .from("categories")
    .upsert(rows)
    .select();
  if (error) return { ok: false, error: error.message };

  // Remove rows deleted in the UI
  const keepIds = upserted.map((r) => r.id);
  if (keepIds.length > 0) {
    const { error: delError } = await client
      .from("categories")
      .delete()
      .not("id", "in", `(${keepIds.join(",")})`);
    if (delError) return { ok: false, error: delError.message };
  }
  revalidatePath("/");
  return { ok: true };
}

export async function saveSettings(settingsMap) {
  const client = db();
  if (!client) return { ok: false, error: "Database not configured" };
  const rows = Object.entries(settingsMap).map(([key, value]) => ({
    key,
    value: Number(value) || 0,
  }));
  const { error } = await client.from("settings").upsert(rows);
  if (error) return { ok: false, error: error.message };
  revalidatePath("/");
  return { ok: true };
}
