import { loadConfig } from "../lib/db";
import AdminConsole from "../components/AdminConsole";

export const dynamic = "force-dynamic";

export default async function Home() {
  const config = await loadConfig();

  if (config.error === "not_configured") {
    return (
      <div className="setup">
        <h2>Almost there — connect your database</h2>
        <p className="sub">
          The app is running, but it can&apos;t find your Supabase keys yet.
        </p>
        <ol>
          <li>In the project folder, copy <code>.env.example</code> to a new file named <code>.env.local</code></li>
          <li>Open your Supabase dashboard → Project Settings → API</li>
          <li>Copy the <b>Project URL</b> into <code>SUPABASE_URL</code></li>
          <li>Copy the <b>service_role</b> key into <code>SUPABASE_SERVICE_ROLE_KEY</code></li>
          <li>Stop the app (Ctrl+C in the terminal) and run <code>npm run dev</code> again</li>
        </ol>
      </div>
    );
  }

  if (config.error) {
    return (
      <div className="setup">
        <h2>Database connected, but something is off</h2>
        <p className="sub">Error from Supabase: {config.error}</p>
        <p className="sub">
          Most common cause: the migration hasn&apos;t been run yet. Open the Supabase
          SQL Editor, paste the whole contents of{" "}
          <code>supabase/migrations/001_init.sql</code>, and click Run. Then refresh
          this page.
        </p>
      </div>
    );
  }

  return <AdminConsole initial={config} />;
}
