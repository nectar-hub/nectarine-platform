import "./globals.css";

export const metadata = {
  title: "Nectarine Pricing Console",
  description: "Admin console for Nectarine Logistics e-commerce platform",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
